package com.example.yasin.trixcalculator;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener{

    private TextView lvalue;
    private TextView dvalue;
    private TextView qvalue;
    private TextView gqvalue;
    private TextView rqvalue;
    private TextView kvalue;
    private TextView tvalue;
    private TextView myscore;
    private TextView otherscore;
    private int ltoosh;
    private int dinari;
    private int banat;
    private int banatmojb;
    private int banatsaleb;
    private int king;
    private int trix;
    private int mscore;
    boolean rst = false;
    private SeekBar lseek;
    private SeekBar dseek ;
    private SeekBar qseek;
    private SeekBar gqseek;
    private SeekBar rqseek;
    private SeekBar kseek ;
    private SeekBar tseek;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        lvalue = findViewById(R.id.Lvalue);
        dvalue = findViewById(R.id.Dvalue);
        qvalue = findViewById(R.id.Qvalue);
        gqvalue = findViewById(R.id.Gqvalue);
        rqvalue = findViewById(R.id.Rqvalue);
        kvalue = findViewById(R.id.Kvalue);
        tvalue = findViewById(R.id.Tvalue);
        myscore = findViewById(R.id.Myscore);
        otherscore = findViewById(R.id.OtheScore);



         lseek = findViewById(R.id.Lseek);
         dseek = findViewById(R.id.Dseek);
         qseek = findViewById(R.id.Qseek);
         gqseek = findViewById(R.id.Qqueen);
         rqseek = findViewById(R.id.Rqueen);
         kseek = findViewById(R.id.Kseek);
         tseek = findViewById(R.id.Tseek);

        Button done = findViewById(R.id.button);

        Button rest = findViewById(R.id.restButton);

        lseek.setOnSeekBarChangeListener(this);
        dseek.setOnSeekBarChangeListener(this);
        qseek.setOnSeekBarChangeListener(this);
        gqseek.setOnSeekBarChangeListener(this);
        rqseek.setOnSeekBarChangeListener(this);
        kseek.setOnSeekBarChangeListener(this);
        tseek.setOnSeekBarChangeListener(this);

        SharedPreferences score =this.getPreferences(Context.MODE_PRIVATE);
        int scr = score.getInt("scr",0);
        Log.d("old", "onCreate: Old "+scr );
        int trx = score.getInt("trix",0);
        if(scr!= 0){

            ltoosh = score.getInt("ltoosh",0);
            dinari = score.getInt("dinari",0);
            banat = score.getInt("banat",0);
            banatmojb = score.getInt("banat+",0);
            banatsaleb = score.getInt("banat-",0);
            king = score.getInt("king",0);
            trix = score.getInt("trix",0);

            lseek.setProgress(ltoosh);
            dseek.setProgress(dinari);
            qseek.setProgress(banat);
            gqseek.setProgress(banatmojb);
            rqseek.setProgress(banatsaleb);
            kseek.setProgress(king);
            tseek.setProgress(trix);

            mscore = ltoosh+dinari+banat+banatmojb+banatsaleb+king+trix;

            if(trix == 0){
                myscore.setText(String.valueOf(mscore));
                otherscore.setText(String.valueOf(-500-mscore));
            }else{
                myscore.setText(String.valueOf(mscore));
                otherscore.setText(String.valueOf(-mscore));
            }

        }



        rest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ltoosh=0;
                dinari=0;
                banat=0;
                banatsaleb=0;
                banatmojb=0;
                king = 0;
                trix = 0;
                lseek.setProgress(0);
                dseek.setProgress(0);
                qseek.setProgress(0);
                gqseek.setProgress(0);
                rqseek.setProgress(0);
                kseek.setProgress(0);
                tseek.setProgress(0);
                mscore = 0;
                myscore.setText("0");
                otherscore.setText("0");

            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    mscore = ltoosh+dinari+banat+banatmojb+banatsaleb+king+trix;

                if(trix == 0){
                    myscore.setText(String.valueOf(mscore));
                    otherscore.setText(String.valueOf(-500-mscore));
                }else{
                    myscore.setText(String.valueOf(mscore));
                    otherscore.setText(String.valueOf(-mscore));
                }

            }
        });


    }




    @Override
    protected void onPause() {
        super.onPause();

        SharedPreferences score =this.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = score.edit();
        editor.putInt("scr",mscore);
        editor.putInt("trix",tseek.getProgress());
        editor.putInt("ltoosh",lseek.getProgress());
        editor.putInt("dinari",dseek.getProgress());
        editor.putInt("banat",qseek.getProgress());
        editor.putInt("banat+", gqseek.getProgress());
        editor.putInt("banat-", rqseek.getProgress());
        editor.putInt("king",kseek.getProgress());

        // Commit the edits!
        editor.apply();

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        int value = seekBar.getProgress();
        switch (seekBar.getId()){

            case R.id.Lseek:
                ltoosh = -15*value;
                lvalue.setText(String.valueOf(value));
                break;

            case R.id.Dseek:
                dinari = -10*value;
                dvalue.setText(String.valueOf(value));
                break;

            case R.id.Qseek:
                banat = -25*value;
                qvalue.setText(String.valueOf(value));
                break;

            case R.id.Rqueen:
                banatsaleb = -25*value;
                rqvalue.setText(String.valueOf(value));
                break;

            case R.id.Qqueen:
                banatmojb = 25*value;
                gqvalue.setText(String.valueOf(value));
                break;

            case R.id.Kseek:
                switch (seekBar.getProgress()){
                    case 0:
                        king = 0;
                        kvalue.setText(String.valueOf(king));
                        break;

                    case 1:
                        king = -75;
                        kvalue.setText(String.valueOf(king));
                        break;

                    case 2:
                        king = +75;
                        kvalue.setText(String.valueOf(king));
                        break;

                    case 3:
                        king = -150;
                        kvalue.setText(String.valueOf(king));
                        break;
                }
                break;

            case R.id.Tseek:
                    if(seekBar.getProgress()!=0){
                        trix = 100 + 50*value;
                        tvalue.setText(String.valueOf(trix));
                    }else{
                        trix = 0;
                        tvalue.setText(String.valueOf(trix));
                    }
                }



    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
